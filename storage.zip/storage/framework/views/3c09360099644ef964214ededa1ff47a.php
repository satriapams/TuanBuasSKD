<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto mt-10 font-sans">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-4xl font-bold text-gray-800">Posts</h1>
            <a href="<?php echo e(route('posts.create')); ?>" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition-colors duration-200">Create New Post</a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <?php if($post->image): ?>
                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="Post Image" class="w-full h-48 object-cover">
                <?php else: ?>
                    <div class="w-full h-48 bg-gray-300 flex items-center justify-center text-gray-500">
                        <span>No Image</span>
                    </div>
                <?php endif; ?>

                <div class="p-6">
                    <h2 class="text-2xl font-semibold text-gray-900 mb-2">
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="hover:text-blue-500"><?php echo e($post->title); ?></a>
                    </h2>

                    <p class="text-gray-700 mb-4"><?php echo e(Str::limit($post->content, 100)); ?></p>

                    <div class="flex items-center justify-between mb-4">
                        <!-- Menampilkan kategori -->
                        <span class="text-sm font-medium text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                            <?php echo e($post->category->name ?? 'No Category'); ?> <!-- Menampilkan kategori dengan fallback -->
                        </span>
                        <span class="text-sm font-medium text-white bg-<?php echo e($post->status == 'published' ? 'green' : 'red'); ?>-500 px-3 py-1 rounded-full">
                            <?php echo e(ucfirst($post->status)); ?>

                        </span>
                    </div>

                    <div class="text-sm text-gray-600 mb-4">
                        <strong>Author:</strong> <?php echo e($post->user->name ?? 'Unknown Author'); ?>

                    </div>


                    <div class="flex items-center justify-between">
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="text-blue-500 hover:text-blue-700 font-semibold">Read More</a>
                        
                        <!-- Kondisi untuk menampilkan tombol edit dan delete jika user adalah admin atau pemilik postingan -->
                        <?php if(auth()->user() && (auth()->id() === 1 && auth()->user()->name === 'admin' || $post->user_id == auth()->id())): ?>
                            <div class="flex items-center space-x-3">
                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="text-gray-500 hover:text-blue-500 font-semibold">Edit</a>
                                <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700 font-semibold">Delete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester3\skd\TuanBuas-backend\resources\views/dashboard/index.blade.php ENDPATH**/ ?>